# Local message

This is a notifications plugin for moodle. It will display notifications to users and allows admins to create them.

This plugin was made as part of a video tutorial series you can find here: https://www.youtube.com/playlist?list=PLnNniujrnp0mFwUNszRcI2OBCiBAh9Iqs

You can get the full course on Udemy:

https://www.udemy.com/course/moodle-developer-course/?referralCode=117EAE3796C1BA840895


## Functionality
- Form for admins to add new notification
- Store read messages for users, do not display twice.
- Store notifications in database.
- Unit testing for message display behaviour
- External function to delete messages
- Modal popup to confirm deletion
